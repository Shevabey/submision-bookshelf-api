# 📚 Bookshelf API 

Submission Bookshelf API - Kelas Belajar Membuat Aplikasi Back-End untuk Pemula

## Requirements

For development, you will only need Node.js >= v.18.16.0 and a node global package, Npm, installed in your environement.

### Set-up and Run
> now install dependencies and run the project

```shell
$ npm install
$ npm run start
```

## Authors

Contributors names and contact info

Mr.Sanz

## License

[![License](http://img.shields.io/:license-mit-blue.svg?style=flat-square)](http://badges.mit-license.org)

- **[MIT license](http://opensource.org/licenses/mit-license.php)**
